import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DetilArtikelPage } from './detil-artikel';

@NgModule({
  declarations: [
    DetilArtikelPage,
  ],
  imports: [
    IonicPageModule.forChild(DetilArtikelPage),
  ],
})
export class DetilArtikelPageModule {}
