import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DetilKomentarPage } from './detil-komentar';

@NgModule({
  declarations: [
    DetilKomentarPage,
  ],
  imports: [
    IonicPageModule.forChild(DetilKomentarPage),
  ],
})
export class DetilKomentarPageModule {}
